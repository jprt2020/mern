const express = require('express'); //
const morgan = require('morgan');
const path = require('path');
const { mongoose } = require('./database');

const app = express(); // app es el servidor

//Settings

app.set('port', process.env.PORT || 3000) //que tome el puerto del servicio de la nube, por defecto 3000

//Middlewares, son funciones que se ejecutan antes de que lleguen a nuestras rutas

app.use(morgan('dev')); //entrega info del cliente
app.use(express.json()); //hace que cada vez que llega un dato psas por esta función

//Routes
app.use('/api/tasks',require('./routes/task.routes'));

//Static files


//console.log(__dirname + '/public');
app.use(express.static((path.join(__dirname, 'public'))));


// Starting the server
app.listen(app.get('port'), () => {
    console.log(`server inicializado on port ${app.get('port')}`);


});